export enum StatusOrderEnum {
    CREATED = 'CREATED',
    PREPARING = 'PREPARING',
    FINISHED = 'FINISHED',
    PAIDOUT = 'PAIDOUT',
    FAILED = 'FAILED'
}
